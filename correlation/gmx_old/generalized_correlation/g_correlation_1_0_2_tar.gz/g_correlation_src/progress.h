#ifndef PROGRESS_H
#define PROGRESS_H

#include <stdio.h>

typedef struct {
  int pos;
  int maxticks;
  int shown_ticks;
  int full;
  char *msg;
  FILE *out;
} t_progress;

void progress_initf(t_progress *pr,FILE* out, char *msg,int maxticks);
void progress_init(t_progress *pr,char *msg,int maxticks);
void progress_show(t_progress *pr);
void progress_resetline(t_progress *pr);
void progress_tick(t_progress *pr);
void progress_forward(t_progress *pr,int plus);
void progress_done(t_progress *pr);

#endif
