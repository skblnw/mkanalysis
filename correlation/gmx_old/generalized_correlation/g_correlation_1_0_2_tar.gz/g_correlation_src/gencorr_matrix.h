#ifndef GENCORR_MATRIX_H
#define GENCORR_MATRIX_H


#include "traj_stuff.h"



void write_matrix(double *mat,int natoms,char *outfile);

void covar_matrix(t_traj *traj, double *mat);
void gauss_corrmatrix(t_traj *traj, double *mat);
void kraskov_corrmatrix(t_mpi *mpi,t_traj *traj,double *mat,int k);
void pearsify(double *mat,int,int);


#endif
