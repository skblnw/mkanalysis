#include <math.h>
#include "decompose.h"
#include "nrutil.h"
#include "smalloc.h"

#define TINY 1.0e-20;

#define min(X,Y) ((X) < (Y)) ? (X) : (Y)
int ludcmp(double *a,int n,int *indx,double *d);

double matrix_det(double *mat,int N) {
  /* contents of mat will be changed */
  double sign=0;
  double prod=1.0;
  int i;
  if (!(decomp_LU_s(mat,N,N,&sign)))
    /*singular elements, determinant will be zero*/
    return 0.0;
  for (i=0;i<N;i++)
    prod*=mat[i*N+i];
  return prod*sign;
};

int decomp_LU_ps(double *mat,int M, int N,int *pivots, double *sign)
{
  int n = min(M,N);
  return ludcmp(mat,n,pivots,sign);
};

int decomp_LU(double *mat, int M, int N) {
  /* M rows, N cols */
  int *pivots;
  int res;
  snew(pivots,min(M,N));
  double sign;
  res=decomp_LU_ps(mat, M, N, pivots,&sign);
  sfree(pivots);
  return res;
};

int decomp_LU_s(double *mat, int M, int N, double *sign) {
  int *pivots;
  int res;
  snew(pivots,min(M,N));
  res=decomp_LU_ps(mat, M, N, pivots,sign);
  sfree(pivots);
  return res;
};

#if 0 
function incorrect --> U
void decomp_LU(double *mat, int M, int N, double *L, double *U) {
  decomp_LU(mat,M,N); 

  for (int i=0; i<min(N,M); i++) {
    L(i,i)=1;
    for (int j=i+1;j<N; j++) {
      L(i,j)=0;
    }
  }
  for (int i=1; i<min(N,M); i++) {
    for (int j=i-1; j>=0; j--)
      U(i,j)=0;
  }
}
#endif

int ludcmp(double *a,int n,int *indx,double *d) {
	int i,imax,j,k;
	double big,dum,sum,temp;
	double *vv;
	imax=0;
	vv=dvector(0,n);
	*d=1.0;
	for (i=0;i<n;i++) {
		big=0.0;
		for (j=0;j<n;j++)
			if ((temp=fabs(a[i*n+j])) > big) big=temp;
		if (big == 0.0) {
		  fprintf(stderr,"warngin: ludcmp -- Singular matrix in routine ludcmp (numerical recpipes)");
		  return 0;
		}
		vv[i]=1.0/big;
	}
	for (j=0;j<n;j++) {
	  for (i=0;i<j;i++) {
	    sum=a[i*n+j];
	    for (k=0;k<i;k++) sum -= a[i*n+k]*a[k*n+j];
	    a[i*n+j]=sum;
	  }
	  big=0.0;
	  for (i=j;i<n;i++) {
	    sum=a[i*n+j];
	    for (k=0;k<j;k++)
	      sum -= a[i*n+k]*a[k*n+j];
	    a[i*n+j]=sum;
	    if ( (dum=vv[i]*fabs(sum)) >= big) {
	      big=dum;
	      imax=i;
	    }
	  }
	  if (j != imax) {
	    for (k=0;k<n;k++) {
	      dum=a[imax*n+k];
	      a[imax*n+k]=a[j*n+k];
	      a[j*n+k]=dum;
	    }
	    *d = -(*d);
	    vv[imax]=vv[j];
	  }
	  indx[j]=imax;
	  if (a[j*n+j] == 0.0) a[j*n+j]=TINY;
	  if (j != (n-1)) {
	    dum=1.0/(a[j*n+j]);
	    for (i=j+1;i<n;i++) a[i*n+j] *= dum;
	  }
	}
	free_dvector(vv,0,n);
	return 1;
}

#undef TINY




