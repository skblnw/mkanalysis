#include "progress.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>

long int lrint(double x);

void progress_initf(t_progress *pr,FILE* out, char *msg,int maxticks) {
  pr->pos=0;
  pr->msg=strdup(msg);
  pr->out=out; fprintf(out,"\n");
  pr->shown_ticks=-1;
  pr->maxticks=maxticks;
  pr->full=50;
};

void progress_init(t_progress *pr,char *msg,int maxticks) {
  progress_initf(pr,stderr,msg,maxticks);
};

void progress_show(t_progress *pr) {
  int full = pr->full;
  int now = lrint(1.0*pr->pos/pr->maxticks*full);
  int i;
  if (now>pr->shown_ticks) {
    pr->shown_ticks=now;
    progress_resetline(pr);
    fprintf(pr->out,"%s ",pr->msg);
    for (i=0;i<now;i++)
      fprintf(pr->out,"*");
    for (i=now;i<full;i++)
      fprintf(pr->out,".");
  }   
};
void progress_resetline(t_progress *pr) {
  fprintf(pr->out,"\r");
};

void progress_tick(t_progress *pr) {
  pr->pos++;
  progress_show(pr);
};

void progress_forward(t_progress *pr,int plus) {
  pr->pos+=plus;
  progress_show(pr);
};

void progress_done(t_progress *pr) {
  free(pr->msg);
  fprintf(pr->out,"\n");
};
