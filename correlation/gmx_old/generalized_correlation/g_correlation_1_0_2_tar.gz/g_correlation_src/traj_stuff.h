#ifndef TRAJ_STUFF_H
#define TRAJ_STUFF_H

#include <futil.h>
#include <statutil.h>
#include <copyrite.h>
#include <smalloc.h>
#include <index.h>
#include <macros.h>
#include <fatal.h>
#include <rmpbc.h>
#include <vec.h>
#include <typedefs.h>
#include <tpxio.h>
#include <do_fit.h>
#include <xvgr.h>
#include <gstat.h>
#include "mpi_stuff.h"

typedef struct {
  atom_id *index;
  int natoms;
  t_topology top;
  rvec *xref;
  matrix box;
  real *w_rls;
  bool bDiffMass;
  rvec x_shift;
} t_fit;

typedef struct { 
  atom_id *index;
  int natoms;
  char *grpname;
} t_index;

typedef struct { 
  int nframes;
  int natoms;
  rvec **x;
  rvec *xav;
} t_traj;

void init_fit(t_fit *afit, char *topfile, char *ndxfile);
void fitit(t_fit *afit, rvec *x,int nat);
void done_fit(t_fit *afit);
void init_ana(t_index *ind, char *topfile, char *ndxfile);
void done_ana(t_index *ind);
void read_traj(t_traj *traj, char *trajfile, t_fit*, t_index*,int skip);
void broadcast_traj(t_traj *traj,t_mpi *mpi);
void done_traj(t_traj*);


#endif
