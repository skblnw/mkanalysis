#ifndef MPI_STUFF_H
#define MPI_STUFF_H

#include "typedefs.h"
#include "progress.h"

#ifdef GMX_MPI
#define MPICC
#endif


#ifdef MPICC
#include <mpi.h>

#else

#define MPI_Bcast(A,B,C,D,E) 
#define MPI_COMM_WORLD 0
#endif


typedef struct {
  int my_rank;
  int num_nodes;
} t_mpi;

typedef struct {
  t_mpi *com;
  double *mat;
  int N,M;
  int count_row;
  int count_col;
  int actual_row;
  int actual_col;
  int bSym;
  double result;
  t_progress prog;
} t_task2D;

void task2D_init(t_task2D*,t_mpi *com,double *mat,int M,int N,bool bSym);
void task2D_push_result(t_task2D*,double res);
int task2D_next_index(t_task2D*,int*,int*);

#define MASTER_RANK 0
#define isMASTER(mpi) ((mpi.my_rank == MASTER_RANK ))
#define isPAR(mpi) ((mpi.num_nodes > 1))

void init_mpi(t_mpi* mpi,int *a,char*** b);
void done_mpi(t_mpi* a);



#endif
