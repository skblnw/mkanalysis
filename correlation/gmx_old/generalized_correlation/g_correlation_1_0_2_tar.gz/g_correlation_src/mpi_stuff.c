#include "mpi_stuff.h"
#include "typedefs.h"
#include "progress.h"

#define __TAG 42  
#define REQUEST_TAG 44


#ifdef MPICC

void init_mpi(t_mpi* mpi,int *argc, char ***argv) {
  MPI_Init( argc,argv );  /*  already includes MPE_Init_log( ); */
  MPI_Comm_size( MPI_COMM_WORLD, &mpi->num_nodes );
  MPI_Comm_rank( MPI_COMM_WORLD, &mpi->my_rank );
  /*fprintf(stderr,"Initialized MPI on node %d for %d nodes\n",  mpi->my_rank,mpi->num_nodes);*/
};

void done_mpi(t_mpi* a) {
  MPI_Finalize();
};

void _receive(void* data,int nr,MPI_Datatype type,int address,int tag,MPI_Comm comm,MPI_Status *stat) 
{
  MPI_Recv(data,nr,type,address,tag,comm,stat);
};

void _send(void* dat, int nr, MPI_Datatype type, int address, int tag,MPI_Comm comm) {
  /*  SLOG(send_log() << "send_to_" << address << "_from_" << my_rank << std::endl)*/
  MPI_Ssend(dat,nr,type,address,tag,comm);
  /* SLOG(send_log() << "...done" << "send_to_" << address << "_from_" << my_rank << std::endl) */
};

void mpi_send_it(t_mpi *m,int address,int dat,int tag) {
  _send(&dat,1,MPI_INT,address,tag,MPI_COMM_WORLD);
};

void mpi_send_i(t_mpi *m,int address,int dat) {
  mpi_send_it(m,address,dat,__TAG);
};

void mpi_send_d(t_mpi *m,int address,double dat) {
  _send(&dat,1,MPI_DOUBLE,address,__TAG,MPI_COMM_WORLD);
};

void mpi_receive_d(t_mpi* m,int address, double *data) {
  MPI_Status stat;
  _receive(data,1,MPI_DOUBLE,address,__TAG,MPI_COMM_WORLD,&stat);
};

void mpi_receive_i(t_mpi* m,int address, int *data) {
 MPI_Status stat;
  _receive(data,1,MPI_INT,address,__TAG,MPI_COMM_WORLD,&stat);
};

int mpi_receive_request(t_mpi* mpi) {
  int data;
  MPI_Status stat;
  _receive(&data, 1,MPI_INT,MPI_ANY_SOURCE,REQUEST_TAG,MPI_COMM_WORLD,&stat);
  return data;
};

void mpi_send_request(t_mpi* mpi) {
  mpi_send_it(mpi,0, mpi->my_rank,REQUEST_TAG);
};

/* =========================================================================================================== */


int task2D_receive_result(t_task2D *t) {
  int slave;
  double data;
  int i,j;
  slave=mpi_receive_request(t->com);
  mpi_receive_d(t->com,slave,&data);
  mpi_receive_i(t->com,slave,&i);
  mpi_receive_i(t->com,slave,&j);
  /*  fprintf(stderr,"receive from node %d for cell (%d,%d) %g\n",slave,i,j,data); */
  /* receives one bogus-result for cell (-1,-1) in beginning from every node, do not store... */
  if (i>=0) {
    t->mat[i*t->M+j]=data;
    if (t->bSym)
      t->mat[j*t->N+i]=data;
  };
  return slave;
};

void task2D_send_result(t_task2D *t) {
  mpi_send_request(t->com);
  mpi_send_d(t->com,0,t->result);
  mpi_send_i(t->com,0,t->actual_row);
  mpi_send_i(t->com,0,t->actual_col);
};



#else

void init_mpi(t_mpi* mpi,int *a,char*** b) {
  mpi->my_rank=0;
  mpi->num_nodes=1;
};
void done_mpi(t_mpi* a) {};

#endif

void task2D_init(t_task2D *t,t_mpi *com,double *mat,int M,int N,bool bSym) {
  t->count_col=0;
  t->count_row=0;
  t->actual_row = -1;
  t->actual_col = -1;
  t->M=M;
  t->N=N;
  t->bSym=bSym;
  t->com=com;
  t->mat=mat;
  if (bSym && M!=N) {
    fprintf(stderr,"task2D_init requesting a symmetric matrix with different dimensions %d x %d\n",M,N);
    exit(1);
    /* replaced this due to compatibility issues gmx3.3 vs gmx3.2 
       gmx_fatal(FARGS,"task2D_init requesting a symmetric matrix with different dimensions %d x %d\n",M,N); */
  };
  if (com->my_rank==MASTER_RANK) 
    progress_init(&t->prog,"",(bSym ? N*(N+1)/2 : N*t->N)); 
  t->prog.full=100; /* parallel tasks are very slow ... get more ticks to view */
  t->prog.pos=-com->num_nodes+1; /* in the beginning there is a start tick for all nodes this is no real progress. */
  /* for sym: N*(N+1)/2 since diagonal elements are ticked, too */
};


int task2D_finished(t_task2D *t) {
  return t->count_row >= t->M;
};

int task2D_newcol(t_task2D *t) {
  if (((t->count_col>t->count_row)&&t->bSym) || (t->count_col>=t->N)) {
    t->count_col=0;
    ++(t->count_row);
  }
  if (!task2D_finished(t)) {
    return (t->count_col)++;
  } else 
    return -1;
}


void task2D_push_result(t_task2D *t,double res) {
  t->result=res;
  if (t->com->num_nodes==1) {
    /* no MPICC or only single node */
    t->mat[t->actual_row*t->M+t->actual_col]=res;
    if (t->bSym)
      t->mat[t->actual_col*t->N+t->actual_row]=res;
  };
};

int task2D_next_index(t_task2D *t, int *i, int *j) {
  if (t->com->num_nodes>1) {
#ifdef MPICC
    int slave;
    int col;
    if (t->com->my_rank==MASTER_RANK) {
      /*one job is for the master himself */
      int col=task2D_newcol(t);
      while ( col>=0 ) {
	int slave=task2D_receive_result(t);
       	progress_tick(&t->prog); /* tick before the job is done */
	mpi_send_i(t->com,slave,col);
	mpi_send_i(t->com,slave,t->count_row);
	col=task2D_newcol(t);
      }
      for (slave=1; slave< t->com->num_nodes; slave++) {
	int nex_slave=task2D_receive_result(t);
	progress_tick(&t->prog);
	mpi_send_i(t->com,nex_slave,-1);
	mpi_send_i(t->com,nex_slave,-1);
      };
      MPI_Barrier(MPI_COMM_WORLD);
      progress_done(&t->prog);
    } else {
      /* non-master nodes */
      task2D_send_result(t);
      mpi_receive_i(t->com,0,j);
      mpi_receive_i(t->com,0,i);
      t->actual_row = *i;
      t->actual_col = *j;
      if (*j < 0) 
	MPI_Barrier(MPI_COMM_WORLD);
      return *j>=0;
    };
    return 0;
#endif
  } else {
    /* no MPICC or only single node */
    *j = t->actual_col = task2D_newcol(t);
    *i = t->actual_row = t->count_row;
    if (t->actual_col<0) 
      progress_done(&t->prog);
    else {
      progress_tick(&t->prog);
    };
    return t->actual_col>=0;
  };
  return 0;
};
