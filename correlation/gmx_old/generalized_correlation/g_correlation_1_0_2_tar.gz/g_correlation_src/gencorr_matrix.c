#include "gencorr_matrix.h"
#include "decompose.h"
#include "kraskov.h"
#include "string.h"
#include "progress.h"

#define PI 3.14159265358979323846

void write_matrix(double *mat,int natoms,char *outfile) {
  int i,j;
  int ncol;
  #define MAX_COL 20
  FILE *out;
  out=ffopen(outfile,"w");
  fprintf(out,"%d x %d [\n",natoms,natoms);
  ncol=0;
  for (i=0;i<natoms;i++)
    for (j=0;j<natoms;j++) {
      fprintf(out,"%10.6g ",mat[j*natoms+i]);
      if (++ncol>MAX_COL) {
	ncol=0; fprintf(out,"\n");
      }
    }
  fprintf(out,"]\n");
  fclose(out);
};

void covar_matrix(t_traj *traj, double *mat) {
  int i,j;
  int a1,a2,d1,d2;
  int nfr;
  int natoms=traj->natoms;
  char buf[200];
  t_progress prog;
  sprintf(buf,"compute covariance matrix for %d atoms",natoms);
  progress_init(&prog,buf,natoms*natoms*DIM);
  for (a1=0,i=0;a1<natoms;a1++) {
    for (d1=0;d1<DIM;d1++, i++) {
      for (a2=0,j=0;a2<natoms;a2++) {
	for (d2=0;d2<DIM;d2++, j++) {
	  mat[i*natoms*DIM+j]=0;
	  for (nfr=0;nfr<traj->nframes;nfr++)
	    mat[i*natoms*DIM+j]+=traj->x[a1][nfr][d1]*traj->x[a2][nfr][d2];
	  mat[i*natoms*DIM+j]/=traj->nframes;
	}
	progress_tick(&prog);
      }
    }
  }
  progress_done(&prog);
};

double entropy(double *mat, int N) {
  /* computes entropy of N-variate Gaussian with Covariance matrix mat */
  return 0.5*(N*(1.0+log(2.0*PI))+log(matrix_det(mat,N))); 
};

void sub_mat(double *res,double *mat,int N,int ar,int er,int ac,int ec) {
  /* this copies elements of rows ar..er-1 and cols ac..ec-1 from the N x N matrix mat into matrix res,
     a sufficient size of res has to be provided by the calling procedure */
  int row,col;
  int i,j;
  for (row=ar,i=0;row<er;row++,i++) 
    for (col=ac,j=0;col<ec;col++,j++) {
      res[i*(ec-ac)+j]=mat[row*N+col]; 
    }
};

void push_mat(double *res,double *mat,int ar, int ac,bool transpose) {
  /* copies all elements of the DIMxDIM matrix mat into the DIMxDIM submatrix
     of the 2*DIM x 2*DIM matrix res, which starts at (ar,ac) */
  int row,col;
  int i,j;
  for (row=ar,i=0;row<(ar+DIM);row++,i++)
    for (col=ac,j=0;col<(ac+DIM);col++,j++) {
        res[row*DIM*2+col]=mat[transpose ? j*DIM+i : i*DIM+j]; 
    }
};

void gauss_corrmatrix(t_traj *traj, double *mat) { 
  double *cov_mat;
  int a1,a2;
  int natoms;
  double sub_mat_d3[DIM*DIM];
  double sub_mat_d6[DIM*DIM*2*2];
  double e1,e2,eg;
  int r,c;
  int Ncov;
  t_progress prog;
  natoms=traj->natoms;
  Ncov=natoms*DIM;
  snew(cov_mat,Ncov*Ncov);
  covar_matrix(traj,cov_mat);
  /*   write_matrix(cov_mat,traj->natoms*DIM,"covar.mat"); */
  progress_init(&prog,"computing generalized correlation:",natoms*(natoms-1)/2);
  for (a1=0;a1<natoms;a1++) {
    mat[a1*natoms+a1]=2000.0;
    for (a2=a1+1;a2<natoms;a2++) {
      progress_tick(&prog);
      sub_mat(sub_mat_d3,cov_mat,Ncov,a1*DIM,a1*DIM+DIM,a1*DIM,a1*DIM+DIM);
      push_mat(sub_mat_d6,sub_mat_d3,0,0,FALSE);
      e1=entropy(sub_mat_d3,3);
      sub_mat(sub_mat_d3,cov_mat,Ncov,a2*DIM,a2*DIM+DIM,a2*DIM,a2*DIM+DIM);
      push_mat(sub_mat_d6,sub_mat_d3,DIM,DIM,FALSE);
      e2=entropy(sub_mat_d3,3);
      sub_mat(sub_mat_d3,cov_mat,Ncov,a1*DIM,a1*DIM+DIM,a2*DIM,a2*DIM+DIM);
      push_mat(sub_mat_d6,sub_mat_d3,0,DIM,FALSE);
      push_mat(sub_mat_d6,sub_mat_d3,DIM,0,TRUE);
      eg=entropy(sub_mat_d6,6);
      mat[a2*natoms+a1]=mat[a1*natoms+a2]=e1+e2-eg;
    }
  }
  sfree(cov_mat);
  progress_done(&prog);
};

void pearsify(double *mat, int N, int dim) {
/* 
   transforms mutual information of dim dimensional objects into generalized correlation coeff. 
*/
  int i;
  for (i=0;i<N*N;i++) {
    if (mat[i]>0) 
      mat[i]=sqrt(1-exp(-2.0/dim* mat[i]));
    else
      mat[i]=0;
  }
};

void kraskov_corrmatrix(t_mpi *com, t_traj *traj, double *mat,int k) {
  int i,j;
  int natoms;
  int p1,p2;
  t_kraskov kraskov;
  t_task2D task2D;
  natoms=traj->natoms;
  for (i=0;i<natoms;i++)
    for (j=0;j<natoms;j++) 
      mat[i*natoms+j]=0;
#define SYMMETRIC_TASK TRUE
  task2D_init(&task2D,com,mat,natoms,natoms,SYMMETRIC_TASK);
  kraskov_prepare(traj,&kraskov);
  while (task2D_next_index(&task2D,&p1,&p2)) {
    if (p1!=p2) {
      task2D_push_result(&task2D, kraskov_wrap(&kraskov,p1,p2,k));
      /*      fprintf(stderr,"node %d stored result %g for (%d,%d)\n",com->my_rank,task2D.result,p1,p2);  */
    } else {
      task2D_push_result(&task2D,2000); 
    }
  };
  kraskov_done(&kraskov);
};

