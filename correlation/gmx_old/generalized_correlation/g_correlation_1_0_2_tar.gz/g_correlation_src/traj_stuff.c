#include "traj_stuff.h"
#include "error.h"
#include "mpi_stuff.h"

void init_fit(t_fit *afit, char *topfile, char *ndxfile) {
  /* atomselection */
  char title[STRLEN];
  char *fitname;
  t_atoms *atoms;
  bool bMass;
  int i;

  read_tps_conf(topfile,title,&afit->top,&afit->xref,NULL,afit->box,FALSE);
  atoms=&(afit->top.atoms);

  fprintf(stderr,"\nChoose a group for the least squares fit\n");
  get_index(atoms,ndxfile,1,&(afit->natoms),&(afit->index),&fitname);
  sfree(fitname);

  /* fit */
  if (afit->natoms < 3) {
    fprintf(stderr,"Need >= 3 points to fit!\n");
    exit(1); 
    /* replaced this due to compatibility issues gmx3.3 vs gmx3.2 
       gmx_fatal(FARGS,"Need >= 3 points to fit!\n"); */
  };
  snew(afit->w_rls,atoms->nr);
  afit->bDiffMass = FALSE;

  bMass = FALSE;
  for(i=0; (i<afit->natoms); i++) {
    afit->w_rls[afit->index[i]]=atoms->atom[afit->index[i]].m;
    bMass = bMass || (atoms->atom[afit->index[i]].m != 0);
    if (i)
      afit->bDiffMass = afit->bDiffMass || (afit->w_rls[afit->index[i]]!=afit->w_rls[afit->index[i-1]]);
  }  
  
  if (!bMass) {
    fprintf(stderr,"All masses in the fit group are 0, using masses of 1\n");
    for(i=0; i<afit->natoms; i++)
      afit->w_rls[afit->index[i]] = 1;
  }

  rm_pbc(&(afit->top.idef),afit->top.atoms.nr,afit->box,afit->xref,afit->xref);
  /* for (i=0;i<afit->natoms; i++) {
     fprintf(stderr,"%10.5g %10.5g %10.5g\n",afit->xref[afit->index[i]][XX],afit->xref[afit->index[i]][YY],afit->xref[afit->index[i]][ZZ]);
     } */
  copy_rvec(afit->xref[afit->index[0]],afit->x_shift);
  reset_x(afit->natoms,afit->index,afit->top.atoms.nr,NULL,afit->xref,afit->w_rls);
  rvec_dec(afit->x_shift,afit->xref[afit->index[0]]);
};


void fitit(t_fit *afit, rvec *x,int nat) {
  int i;
  /*k�nnte probleme geben, wenn in Trajektorie andere anzahl atome als in .tpr,
    aber da dass nicht vorkommen soll...ignorieren */
  rm_pbc(&(afit->top.idef),nat,afit->box,x,x);
  reset_x(afit->natoms,afit->index,nat,NULL,x,afit->w_rls);
  do_fit(nat,afit->w_rls,afit->xref,x); 
  for(i=0; i<nat; i++)
  rvec_inc(x[i],afit->x_shift); 
};

void done_fit(t_fit *afit) {
  sfree(afit->index);
  sfree(afit->xref);
  sfree(afit->w_rls);
};

void init_ana(t_index *ind, char *topfile, char *ndxfile){
  t_topology top;
  rvec *xref;
  matrix box;
  char title[STRLEN];
  t_atoms *atoms;

  read_tps_conf(topfile,title,&top,&xref,NULL,box,FALSE);
   atoms=&(top.atoms);

  fprintf(stderr,"\nChoose a group for the analysis\n");
  get_index(atoms,ndxfile,1,&(ind->natoms),&(ind->index),&(ind->grpname));
  if (fn2ftp(topfile)!=efPDB) 
    done_top(&top);
  sfree(xref);
};

void done_ana(t_index *ind) {
  sfree(ind->grpname);
  sfree(ind->index);
};

void read_traj(t_traj *traj, char *trxfile, t_fit* afit, t_index* _index,int skip) {
  int status;
  int nat; 
  int used_atoms;
  int i;
  int nread,snew_size;
  real t;
  rvec *xread;
  matrix box;
  atom_id *index;
  nat=read_first_x(&status,trxfile,&t,&xread,box);
  used_atoms = _index ? _index->natoms : nat;
  traj->natoms=used_atoms;
  if (_index) 
    index=_index->index;
  else {
    snew(index,used_atoms);
    for (i=0;i<used_atoms;i++)
      index[i]=i;
  }
    
  fprintf(stderr,"read %d atoms from trajectory file %s\n",used_atoms,trxfile);
  snew(traj->xav,used_atoms);
  snew(traj->x,used_atoms);
  for (i=0;i<used_atoms;i++)
    clear_rvec(traj->xav[i]);

  traj->nframes=0;
  nread = 0;
  snew_size=0;
  do {
    if (nread % skip == 0) { 
      if (afit)
	      fitit(afit,xread,nat);
      for (i=0;i<used_atoms;i++)
	rvec_inc(traj->xav[i],xread[index[i]]);
      if (traj->nframes>=snew_size) {
	snew_size+=100;
	for(i=0; i<used_atoms; i++)
	  srenew(traj->x[i],snew_size);
      }
      for(i=0; i<used_atoms; i++)
	copy_rvec(xread[index[i]],traj->x[i][traj->nframes]);
      ++traj->nframes;
      ++nread;
    } else
      ++nread;
  } while (read_next_x(status,&t,nat,xread,box));
  close_trj(status);
  fprintf(stderr,"finished with reading %d frames from trajectory \n",traj->nframes);

  for(i=0; i<used_atoms; i++)
    svmul(1.0/traj->nframes,traj->xav[i],traj->xav[i]);
  
  if (!_index)
    sfree(index);	 
  sfree(xread);
};

void broadcast_traj(t_traj *traj,t_mpi *mpi){
#ifdef MPICC
  int i,nfr;
  if (mpi->num_nodes>1) {
    fprintf(stderr,"broadcasting trajectory ...\n");
    MPI_Bcast(&traj->natoms,1,MPI_INT,MASTER_RANK,MPI_COMM_WORLD);
    MPI_Bcast(&traj->nframes,1,MPI_INT,MASTER_RANK,MPI_COMM_WORLD);
    if (mpi->my_rank>0) {
      snew(traj->x,traj->natoms);
      snew(traj->xav,traj->natoms);
      for (i=0;i<traj->natoms;i++) 
	snew(traj->x[i],traj->nframes);
    };
    for (i=0;i<traj->natoms;i++) 
      MPI_Bcast(traj->x[i][0],traj->nframes*sizeof(rvec),MPI_BYTE,MASTER_RANK,MPI_COMM_WORLD);
    MPI_Bcast(traj->xav[0],traj->natoms*sizeof(rvec),MPI_BYTE,MASTER_RANK,MPI_COMM_WORLD);
  }    
  //fprintf(stderr,"node %d nframes %d natoms %d\n",mpi->my_rank,traj->nframes,traj->natoms);
#endif
};

void done_traj(t_traj *traj) {
  int i;
  sfree(traj->xav);
  for (i=0;i<traj->natoms;i++)
    sfree(traj->x[i]);
  sfree(traj->x);
};
