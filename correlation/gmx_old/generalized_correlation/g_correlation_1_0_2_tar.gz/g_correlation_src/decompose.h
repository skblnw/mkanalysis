#ifndef DECOMPOSE_H
#define DECOMPOSE_H

extern int decomp_LU_s(double *mat,int M, int N, double *sign);
extern int decomp_LU_ps(double *mat,int M, int N, int *pivots, double *sign);
extern int decomp_LU(double *mat,int M, int N);
/* performs LU decomp: LU=A;
 on exit L and U are stored as upper and lower part of A, unit diagonal elements of L
 are not stored. 
 invalid: void decomp_LU(Matrix A, Matrix &L, Matrix &U);
 on exit L and U are upper and lower triangular matrix */

extern double matrix_det(double *mat,int N);
/* returns determinatnt of N x N matrix mat,  contents of mat will be changed after call */

#endif
